-- by mor2000

--------------------
-- UPK_Unspecified (provides standard module configuration options)

UniversalProcessKit.addModule("unspecified",UniversalProcessKit)

