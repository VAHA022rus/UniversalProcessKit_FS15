-- by mor2000

-- debug modes

-- 0 none - only errors from the game engine might occure/ super silent dont bother about anything mode
-- 1 errors - log faulty usage or configuration which might lead to other errors  -- default
-- 2 infos - log useful information to see if your attributes are used right (mostly when mod loaded) 

-- debug modes for developers

-- 3 functions - log which functions are called
-- 4 everything - log every manually set print
-- 5 everything+ - log more than everything (cannot be changed in-game)

debugMode=1