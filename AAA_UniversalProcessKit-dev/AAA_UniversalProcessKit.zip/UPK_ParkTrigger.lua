-- by mor2000

--------------------
-- ParkTrigger


local UPK_ParkTrigger_mt = ClassUPK(UPK_ParkTrigger,UniversalProcessKit)
InitObjectClass(UPK_ParkTrigger, "UPK_ParkTrigger")
UniversalProcessKit.addModule("parktrigger",UPK_ParkTrigger)

function UPK_ParkTrigger:new(nodeId, parent)
	printFn('UPK_ParkTrigger:new(',nodeId,', ',parent,')')
	local self = UniversalProcessKit:new(nodeId, parent, UPK_ParkTrigger_mt)
	registerObjectClassName(self, "UPK_ParkTrigger")
	
	self.allowedVehicles={}
	self.allowedVehicles[UniversalProcessKit.VEHICLE_MOTORIZED] = getBoolFromUserAttribute(nodeId, "allowMotorized", true)
	
	self.allowWalker = false
	
	self:addTrigger()
	
	self:printFn('UPK_ParkTrigger:new done')
	
	return self
end

function UPK_ParkTrigger:triggerUpdate(vehicle,isInTrigger)
	self:printFn('UPK_ParkTrigger:triggerUpdate(',vehicle,', ',isInTrigger,')')
	if self.isEnabled and vehicle~=nil then
		if isInTrigger then
			vehicle.nonTabbable = true
		elseif not SpecializationUtil.hasSpecialization(NonTabbable, vehicle.specializations) then
			vehicle.nonTabbable = nil
		end
	end
end

