# UniversalProcessKit für LS15

Dieses projekt befindet sich zur Zeit in der "Konvertierungsphase" aus den LS13-Skripten. Unter der Haube vom UPK hat sich sehr viel verändert und nach und nach werden jetzt die Module ergänzt.

Bisher enthaltene Module:

- base
- entitytrigger
- displaytrigger
- processor
- unspecified

##Changelog

__V0.1.3__

- Modultyp unspecified hinzugefügt
- geändert: enableChildrenIfProcessing
- neu: addIfProcessing
- neu: emptyFillTypesIfProcessing
- neu: enableChildrenIfNotProcessing
- neu: disableChildrenIfProcessing
- neu: disableChildrenIfNotProcessing
- umbenannt: von „equal“ zu „uniform“ in outcomeVariationType
