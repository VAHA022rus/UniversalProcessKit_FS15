



	print('------------------')
	
	local gui_StatisticView = _g.g_gui.guis.StatisticView.target
	
	local emptyPage = GuiElement:new() --gui_StatisticView.pages[StatisticView.PAGE_STATISTICS].element.elements[1].parent)
	--emptyPage.parent = gui_StatisticView.pages[StatisticView.PAGE_STATISTICS].element.elements[1].parent
	
	emptyPage.isUpkStatistics = true
	emptyPage.screenAlignStr = "topLeft";
	emptyPage.positionOriginStr = "topLeft";
	
	
	
	
	print('==================')
	
	emptyPage.onDrawCallback = function(self)
		print('drawing emptyPage')
		--headingBackgroundOverlay:render()
		setTextAlignment(RenderText.ALIGN_LEFT);
		setTextBold(false)
		setTextColor(1,1,1,1);
		renderText(0,0,0.019166666952272,"TEST234")
		
		
	end
	
	
	
	
	
	local oldStatisticViewdraw = StatisticView.draw
	StatisticView.draw = function(...)
		local result = {oldStatisticViewdraw(...)}
		local pageId = gui_StatisticView:getCurrentPageId()
		print('pageId is '..tostring(pageId))
		if gui_StatisticView.pages[pageId].element.isUpkStatistics then
			print('page is isUpkStatistics')
			emptyPage:draw()
		end
		return unpack(result)
	end
	
	
	local myPageId = nil
	if gui_StatisticView.addPage(gui_StatisticView, StatisticView.PAGE_NEXT_ID, emptyPage, "Testseite")~=nil then
		myPageId = StatisticView.PAGE_NEXT_ID - 1
	end
	
	
	
	-- profiles
	
	local profile_bgColorBlack2 = g_gui:getProfile('bgColorBlack2')
	local profile_statisticTitles = g_gui:getProfile('statisticTitles')
	local profile_bgColorWhite90 = g_gui:getProfile('bgColorWhite90')
	
	
	local drawArea = GuiElement:new()
	drawArea:setPosition(0,0)
	drawArea:setSize(0.37760416666667,0.47500000707805)
	
	local heading = GuiElement:new()
	heading:setSize(0.37760416666667,0.47500000707805)
	heading:loadProfile(profile_bgColorBlack2)
	heading.profile = 'bgColorBlack2'
	
	local heading_text = GuiElement:new()
	heading_text:loadProfile(profile_statisticTitles)
	heading_text.text="TEsT"
	heading.profile = 'statisticTitles'
	
	heading:addElement(heading_text)
	
	emptyPage:loadProfile(profile_bgColorWhite90)
	emptyPage.profile = 'bgColorWhite90'
	emptyPage:setSize(0.37760416666667,0.47500000707805)
	emptyPage:setPosition(0,0)
	emptyPage:addElement(heading)
	
	
	print('==================')
	
	--disabled
	
	--[[
	
	draw bereich Statistics links
	
		["absPosition"] = {
			[1] = 0.109375;
			[2] = 0.29541666361814;
		["offset"] = {
			[1] = 0;
			[2] = 0;
		};
		["positionOriginStr"] = "topLeft";
		["size"] = {
			[1] = 0.37760416666667;
			[2] = 0.47500000707805;
		};
		["position"] = {
			[1] = 0;
			[2] = 0;
		};
	
	Überschrift Hintergrund
	
		["size"] = {
			[1] = 0.37760416666667;
			[2] = 0.033333333830039;
		};
		["position"] = {
			[1] = 0;
			[2] = 0;
		};
		["absPosition"] = {
			[1] = 0.109375;
			[2] = 0.29541666361814;
		};
		["offset"] = {
			[1] = 0;
			[2] = 0;
		};
		["profile"] = "bgColorBlack2";
	
	Überschrift Text
	
		["textPreSelectedColor"] = {
			[1] = 1;
			[2] = 1;
			[3] = 1;
			[4] = 1;
		};
		["profile"] = "statisticTitles";
		["text"] = "STATISTIKEN";
		["useUpperCase"] = "true";
		["position"] = {
			[1] = 0.010416666666667;
			[2] = 0.013333333532015;
		};
		["absPosition"] = {
			[1] = 0.11979166666667;
			[2] = 0.74208333694066;
		};
		["size"] = {
			[1] = 0;
			[2] = 0;
		};
	
	]]--
	print(tableShow(gui_StatisticView.pages[StatisticView.PAGE_STATISTICS].element.elements[1],"stats",3))
	
	print('==================')
	
	print(tableShow(emptyPage,"emptyPage",3))
	
	print('==================')
	--[[
	
	print('------------------')
	
	print('StatisticView is '..tostring(StatisticView))
	for k,v in pairs(StatisticView) do
		print('in StatisticView: '..tostring(k)..' = '..tostring(v))
	end
	
	print('------------------')
	]]--
		
	print('myPageId is '..tostring(myPageId))
	
	print('emptyPage:isa(GuiElement) is '..tostring(emptyPage:isa(GuiElement)))
	
	
	local ClonElements = gui_StatisticView.pages[StatisticView.PAGE_STATISTICS].element.elements
	
	--local elements3 = ClonElements[1]:clone(emptyPage)--bgColorBlack
	
	local element = _g.g_gui.guis.StatisticView.target.pages[1].element.elements[2].elements[1]:clone()
	--local element2 = gui_StatisticView.pages[1].elements[2].clone(emptyPage)
	--local element2 = gui_StatisticView.pages[1].element.elements[2].elements[1].elements[1]:clone(emptyPage)
	--element2.text = "Beispiel"
	
	--emptyPage:addElement(element)
	
	local drawElement = GuiElement:new()
	drawElement.draw = function()
		print('drawing drawElement')
	end
	--gui_StatisticView.pages[1]:addElement(drawElement)
	
	print('------------------')
	
	print('emptyPage is '..tostring(emptyPage))
	print('gui_StatisticView.pages[myPageId] is '..tostring(gui_StatisticView.pages[myPageId]))
	
	--[[
	local elements = {}
	elements[1] = GuiElement:new(self) --base
	elements[2] = g.g_gui.guis.StatisticView.target.pages[1].element.elements[2]:clone(elements[1]) --bgColorWhite90
	local xOffset = elements[2].absPosition[1]-(1 - elements[2].absPosition[1]- elements[2].size[1])
	local ClonElements = g.g_gui.guis.StatisticView.target.pages[1].element.elements[2].elements 
	elements[3] = ClonElements[1]:clone(elements[1])--bgColorBlack
	elements[4] = ClonElements[1].elements[1]:clone(elements[1])--statisticTitles
	elements[4].text = string.format("%s %d",g_i18n:getText(self.animal),self.StationNr)
	]]--
	
	print('------------------')
	
	print('emptyPage is '..tostring(emptyPage))
	for k,v in pairs(emptyPage) do
		print('in emptyPage: '..tostring(k)..' = '..tostring(v))
	end
	
	print('------------------')
	
	print('gui_StatisticView.pages[myPageId] is '..tostring(gui_StatisticView.pages[myPageId]))
	for k,v in pairs(gui_StatisticView.pages[myPageId]) do
		print('in gui_StatisticView.pages[myPageId]: '..tostring(k)..' = '..tostring(v))
	end
	
	-- alpha
	
	print('------------------')
	
	local elementNew = GuiElement:new()
	
	
	
	
	
	for k,v in pairs(elementNew) do
		print('in elementNew: '..tostring(k)..' = '..tostring(v))
	end
	
	print('------------------')
	
	print('emptyPage.elements is '..tostring(emptyPage.elements))
	
	for k,v in pairs(emptyPage.elements) do
		print('in emptyPage.elements: '..tostring(k)..' = '..tostring(v))
	end
	
	print('------------------')