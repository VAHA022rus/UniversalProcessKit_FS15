-- hier die neuen platzierbaren Objekte registrieren/ dem Spiel bekannt machen
-- 1) füge dein Objekt in der modDesc.xml ein und erzeuge eine XML für dein Objekt
-- 2) bennene dein Objekt in dieser XML wie folgt: <placeableType>DeinObjektName</placeableType>
-- 3) diesen Objekt-Namen hier registrieren lassen - registerPlaceableType("DeinObjektName", PlaceableUPK)

-- register new PlaceableUPKs here
-- 1) mention your new object in modDesc and the corresponding XML
-- 2) in that XML, name your object: <placeableType>YourObjectName</placeableType>
-- 3) this object name should be registered here - registerPlaceableType("YourObjectName", PlaceableUPK)

registerPlaceableType("UPKAnimatorTest", PlaceableUPK)

